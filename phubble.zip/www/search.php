<?php
include_once 'inc/mysql.php';
include_once 'inc/header.php';
include_once 'inc/navigation.php';

$query = $_GET['q'];
$result = mysql_query("SELECT * FROM things WHERE name LIKE '%$query%' or description LIKE '%$query%'");
echo "<h3>Search Results for $query</h3>";
while($row = mysql_fetch_assoc($result)){
    echo "<a href='/view.php?id=".$row['id']."'><div class='your-images'><p>".$row['name']."</p><img width=100px height=100px src='uploads/".$row['filename']."' alt='".$row['name']."'></div>";
}
?>