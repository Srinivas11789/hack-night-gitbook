<?php
function session_begin($username = ''){
    if(!isset($_COOKIE['session']) && $username != ''){
        setcookie("session", base64_encode(serialize($username)), time()+3600);
    }
    else if (isset($_COOKIE['session']) && $username == ''){
        global $username;
        $username = unserialize(base64_decode($_COOKIE['session']));
    }
}
?>