<?php
include_once 'inc/session.php';
session_begin();
setlocale(LC_MONETARY, 'en_US');
?>

<!DOCTYPE html>
<html>
<head>
    <title></title>
    <script src="js/jquery-1.10.2.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap-theme.min.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>