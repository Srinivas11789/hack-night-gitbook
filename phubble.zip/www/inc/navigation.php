<nav class="navbar navbar-default" role="navigation">
  <!-- Brand and toggle get grouped for better mobile display -->
  <div class="navbar-header">
    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
      <span class="sr-only">Toggle navigation</span>
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>
    </button>
    <a class="navbar-brand" href="/">Phubble</a>
  </div>

  <!-- Collect the nav links, forms, and other content for toggling -->
  <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
    <ul class="nav navbar-nav">
      <?php if(!isset($username)){ ?>
      <li><a href="register.php">Register</a></li> 
      <li><a href="login.php">Login</a></li> 
      <?php } else { ?>
      <li><a href="profile.php">Profile</a></li> 
      <li><a href="logout.php">Logout</a></li> 
      <?php } ?>
      <li><a href="create.php">Upload Image</a></li> 
      <li><a href="#"></a></li>
    </ul>
    <ul class="nav navbar-nav navbar-right">
      <form method="GET" action="search.php" class="navbar-form navbar-left" role="search">
        <div class="form-group">
          <input name="q" type="text" class="form-control" placeholder="Search">
        </div>
        <button type="submit" class="btn btn-default">Search</button>
      </form>
    </ul>
  </div><!-- /.navbar-collapse -->
</nav>