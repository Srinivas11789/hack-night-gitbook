<?php
    $mysql = mysql_connect('localhost', 'root', 'password') or die(mysql_error());
    mysql_select_db( "webapp" ) or die(mysql_error());

    function mysql_insert($table, $inserts) {
        $values = array_values($inserts);
        $keys = array_keys($inserts);
            
        return mysql_query('INSERT INTO `'.$table.'` (`'.implode('`,`', $keys).'`) VALUES (\''.implode('\',\'', $values).'\')');
    }
?>