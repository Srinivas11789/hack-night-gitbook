<?php
include_once 'inc/mysql.php';
include_once 'inc/header.php'; 
include_once 'inc/navigation.php'; 

if(!isset($username)){
    header('Location: /login.php');
    exit();
}

$result = mysql_query("SELECT id from users WHERE username='$username'");
$id = mysql_fetch_assoc($result)['id'];
?>

<a href="create.php">Sell your photo!</a><br/>

<h1>Your Photos</h1>
<?php
$result = mysql_query("SELECT id, name, filename from things WHERE owner='$id'");
while($row = mysql_fetch_assoc($result)){

    echo "<a href='/view.php?id=".$row['id']."'><div class='your-images'><p>".$row['name']."</p><img width=100px height=100px src='uploads/".$row['filename']."' alt='".$row['name']."'></div>";
}
?>