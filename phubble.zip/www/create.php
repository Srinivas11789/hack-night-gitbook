<?php
include 'inc/mysql.php';
include_once 'inc/header.php'; 
include_once 'inc/navigation.php'; 

if( !isset($username) ){
    header('Location: /login.php');
    exit();
}

$result = mysql_query("SELECT id from users WHERE username='$username'");
$id = mysql_fetch_assoc($result)['id'];
?>

Upload your Photo!

<form role="form" action="upload.php" method="POST" enctype="multipart/form-data">
  <div class="form-group">
    <label for="exampleInputEmail1">Name</label>
    <input class="form-control" type="text" name="name">
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Description</label>
    <textarea class="form-control" name="description"></textarea>
  </div>
  <div class="form-group">
    <label for="exampleInputFile">Upload your Photo</label>
    <input class="form-control" type="file" name="file" id="file">
  </div>
  <div class="form-group">
    <label for="exampleInputFile">Price</label>
    <input class="form-control" type="text" name="price">
  </div>
  <input type="hidden" name="owner" value="<?php echo $id;?>">
  <button type="submit" class="btn btn-default">Submit</button>
</form>