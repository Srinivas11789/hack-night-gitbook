from bs4 import BeautifulSoup
import urllib2
import requests
import os
import StringIO
import random

hipster = ['8-bit', 'seitan', '3', 'wolf', 'moon,', 'fanny', 'pack', 'McSweeneys', 'yr', 'hashtag', 'trust', 'fund', 'distillery.', 'Sartorial', 'iPhone', 'Cosby', 'sweater', 'seitan,', 'forage', 'single-origin', 'coffee', 'cray', 'authentic', 'narwhal', 'gluten-free', 'aesthetic', 'swag.', 'Blue', 'Bottle', 'banjo', 'selfies,', 'street', 'art', 'deep', 'v', 'vegan', 'Truffaut', 'aesthetic', 'narwhal', 'DIY', 'Godard', 'meh', 'tote', 'bag', 'Schlitz.', 'Food', 'truck', 'banjo', 'blog', 'meh,', 'slow-carb', 'drinking', 'vinegar', 'Helvetica', 'church-key', 'typewriter', 'tousled', 'kitsch', 'jean', 'shorts', 'fashion', 'axe', 'organic', 'Odd', 'Future.', 'Messenger', 'bag', 'Marfa', 'Bushwick', 'semiotics', 'quinoa', 'mlkshk.', 'Cred', 'next', 'level', 'before', 'they', 'sold', 'out', 'cardigan', 'Banksy', 'Tonx,', 'kitsch', 'tousled', 'actually', 'deep', 'v', 'church-key', 'umami', 'XOXO', 'Intelligentsia.', 'High', 'Life', 'fixie', 'VHS,', 'keytar', 'pork', 'belly', 'cray', 'hoodie', '8-bit.\n\nEtsy', 'hella', 'lomo', 'aesthetic.', 'Chia', 'fashion', 'axe', 'wayfarers,', 'kale', 'chips', 'raw', 'denim', 'retro', 'Terry', 'Richardson', 'mumblecore', 'flexitarian', 'American', 'Apparel', 'farm-to-table.', 'Bespoke', 'stumptown', 'selvage', 'artisan,', 'flexitarian', '3', 'wolf', 'moon', 'slow-carb.', 'Jean', 'shorts', 'beard', 'Intelligentsia', 'mixtape,', 'wayfarers', 'bespoke', 'forage', 'Carles', 'pour-over', 'Helvetica', 'aesthetic', 'deep', 'v', 'try-hard', 'butcher.', 'Skateboard', 'pour-over', 'squid,', 'brunch', 'Shoreditch', 'High', 'Life', 'you', 'probably', "haven't", 'heard', 'of', 'them.', 'Brunch', 'chillwave', '3', 'wolf', 'moon', 'High', 'Life.', 'Tousled', 'cliche', 'organic,', 'PBR&B', 'squid', 'locavore', 'hella', 'single-origin', 'coffee', 'flexitarian.\n\nSemiotics', 'paleo', 'mumblecore,', 'seitan', 'readymade', 'scenester', 'fixie', 'occupy', 'artisan', 'ennui.', 'Sriracha', 'yr', 'plaid,', 'bespoke', 'polaroid', 'vinyl', 'literally', 'distillery', 'direct', 'trade', 'chambray', 'street', 'art', 'authentic.', 'Ethnic', 'scenester', 'leggings,', 'VHS', 'umami', 'deep', 'v', 'High', 'Life', 'Blue', 'Bottle', 'gluten-free', 'blog.', 'Meggings', 'kitsch', 'Helvetica', 'pug.', 'Fashion', 'axe', 'literally', 'chillwave,', 'post-ironic', 'selvage', 'Neutra', 'DIY', 'trust', 'fund', 'cliche', 'Portland', 'flannel', 'dreamcatcher', 'hella', 'Wes', 'Anderson', '8-bit.', 'Ennui', 'hoodie', 'banh', 'mi,', 'synth', 'next', 'level', 'Portland', '3', 'wolf', 'moon', 'organic', 'Cosby', 'sweater.', 'Bespoke', 'art', 'party', 'craft', 'beer', 'Intelligentsia', 'cray', 'mustache.\n\nSwag', 'next', 'level', 'beard', 'mlkshk', 'quinoa.', 'Wolf', 'authentic', 'wayfarers,', 'distillery', 'PBR&B', 'fixie', 'chia', 'banjo', 'ennui', 'forage', 'letterpress.', 'Keffiyeh', 'Pitchfork', 'polaroid', 'gluten-free', 'chambray', 'chillwave', 'meggings,', 'bespoke', 'Tumblr', 'Banksy', 'art', 'party', 'Portland.', 'Terry', 'Richardson', 'tofu', 'single-origin', 'coffee', 'Portland.', 'Flexitarian', 'tofu', 'direct', 'trade,', 'Wes', 'Anderson', 'retro', 'pork', 'belly', 'messenger', 'bag', 'sustainable', 'American', 'Apparel', 'jean', 'shorts.', 'Ugh', 'gentrify', 'chia', 'lomo', 'High', 'Life.', 'Vice', 'Helvetica', 'pop-up', 'Etsy,', 'sustainable', 'squid', 'selvage', 'Bushwick', 'roof', 'party', 'synth', 'distillery.']

def process_file(url):
    local_filename = url.split('/')[-1]

    r = requests.get(url, stream=True)
    f = StringIO.StringIO()
    for chunk in r.iter_content(chunk_size=1024): 
        if chunk: 
            f.write(chunk)
            f.flush()
    upload = {'file': ('image.jpg', f.getvalue(), 'image/jpeg')}
    description = " ".join(random.sample(hipster, 10))
    data = {'name':local_filename.split('.')[0], 'description':description, 'price':'1.00', 'owner':'1.00' }

    r = s.post('http://localhost/upload.php', files=upload, data=data)
    print data
    f.close()


soup = BeautifulSoup(requests.get('http://imgur.com/').text)

images = []

for img in soup.find_all('img'):
    if 'i.imgur' in img.get('src'):
        images.append('http:' + img.get('src'))

global s
s = requests.Session()
creds = {'username': 'user', 'password': 'user'}
s.post("http://localhost/login.php", data=creds)
# print images
for x in images:
    process_file(x)
