<?php
include 'inc/mysql.php';
include 'inc/session.php';

session_begin();

if( !isset($username) ){
    header('Location: /login.php');
    exit();
}

$allowedExts = array("gif", "jpeg", "jpg", "png");
$temp = explode(".", $_FILES["file"]["name"]);
if ((($_FILES["file"]["type"] == "image/gif")
|| ($_FILES["file"]["type"] == "image/jpeg")
|| ($_FILES["file"]["type"] == "image/jpg")
|| ($_FILES["file"]["type"] == "image/pjpeg")
|| ($_FILES["file"]["type"] == "image/x-png")
|| ($_FILES["file"]["type"] == "image/png"))
&& ($_FILES["file"]["size"] < 5000000))
  {
  if ($_FILES["file"]["error"] > 0)
    {
    echo "Return Code: " . $_FILES["file"]["error"] . "<br>";
    }
  else
    {
    $md5 = md5_file($_FILES["file"]["tmp_name"]);
    $filename = $md5 . $_FILES["file"]["name"];
    if (strlen($filename) > 128){
        exit('Filename too long');
    }

    move_uploaded_file($_FILES["file"]["tmp_name"], "uploads/" . $md5 . $_FILES["file"]["name"]);
    mysql_insert('things', array(
        'owner' => $_POST['owner'],
        'name' => $_POST['name'],
        'filename' => $filename,
        'description' => $_POST['description'],
        'price' => floatval($_POST['price'])
    ));
    }
    exit();
    header('Location: /profile.php');
  }
else{
    echo "Invalid file";
}
?>