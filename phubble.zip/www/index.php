<?php
include_once 'inc/mysql.php';
include_once 'inc/header.php'; 
include_once 'inc/navigation.php'; 

$result = mysql_query('SELECT id, name, filename FROM things ORDER BY RAND() LIMIT 100');
while($row = mysql_fetch_assoc($result)){
    echo "<a href='/view.php?id=".$row['id']."'><div class='your-images'><p>".$row['name']."</p><img width=100px height=100px src='uploads/".$row['filename']."' alt='".$row['name']."'></div>";
}
?>
