<?php
include_once 'inc/mysql.php';
include_once 'inc/header.php'; 
include_once 'inc/navigation.php'; 

$id = $_GET['id'];
$result = mysql_query("DELETE FROM things WHERE id=$id");
if ($result){
    echo "Photo Deleted!";
} else {
    echo mysql_error();
}
?>