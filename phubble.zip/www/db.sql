CREATE DATABASE webapp;
USE webapp;
CREATE TABLE users (id int(10) unsigned AUTO_INCREMENT, username varchar(128), password char(32), PRIMARY KEY (id));
CREATE TABLE things (id int(10) unsigned AUTO_INCREMENT, owner int(10) unsigned, name varchar(128), filename varchar(128), description TEXT, price DECIMAL(10, 2), PRIMARY KEY (id));
INSERT INTO users (username, password) VALUES ('admin', MD5('senoradminman'));