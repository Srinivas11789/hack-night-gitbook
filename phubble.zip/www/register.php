<?php
include_once 'inc/mysql.php';
include_once 'inc/header.php'; 
include_once 'inc/navigation.php'; 

if ($_SERVER['REQUEST_METHOD'] == "POST"){
    $username = $_POST['username'];
    $password = md5($_POST['password']);


    $result = mysql_query("SELECT COUNT(id) as count from users WHERE username='$username'");

    $row = mysql_fetch_assoc($result);
    if ( $row["count"] != 0 ){
        exit("Looks like that username's taken");
    }

    mysql_insert('users', array(
        'username' => $username,
        'password' => $password
    ));

    mysql_close($mysql);
    session_begin($username);
}

?>

<h3>Register</h3>
<form role="form" method="POST">
  <div class="form-group">
    <label for="exampleInputEmail1">Username</label>
    <input type="text" class="form-control" name="username" placeholder="Enter Username">
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Password</label>
    <input type="password" class="form-control" name="password" placeholder="Password">
  </div>
  <button type="submit" class="btn btn-default">Submit</button>
</form>