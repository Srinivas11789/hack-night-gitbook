<?php
include_once 'inc/mysql.php';
include_once 'inc/header.php'; 
include_once 'inc/navigation.php'; 

$id = $_GET['id'];

$result = mysql_query("SELECT * from things WHERE id=$id");
echo mysql_error();
while($row = mysql_fetch_assoc($result)){
    $users = mysql_query("SELECT username from users WHERE id='".$row['owner']."'");
    $user = mysql_fetch_assoc($users)['username'];
    ?>

    <h1><?php echo $row['name']; ?> by <?php echo $user; ?></h1>
    <img src="uploads/<?php echo $row['filename']; ?>">
    <p><?php echo $row['description']; ?></p>
    <p><?php echo '$'.$row['price']; ?></p>
    <?php
    if (isset($username) && $user == $username){
        echo "<a href='delete.php?id=$id'>Delete?</a>";
    }
}
mysql_close($mysql);
?>